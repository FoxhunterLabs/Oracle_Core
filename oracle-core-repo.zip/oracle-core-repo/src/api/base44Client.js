/**
 * Minimal base44 client stub.
 *
 * Your component expects:
 * base44.integrations.Core.InvokeLLM({ prompt, response_json_schema })
 *
 * This stub:
 * - If VITE_LLM_ENDPOINT is set, POSTs { prompt, schema } and expects JSON back.
 * - Otherwise returns a local mock response (so the app runs out of the box).
 */

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function mockFromPrompt(prompt = "") {
  // Very light mock — keeps the UI feeling alive without any external service.
  const lower = prompt.toLowerCase();

  // naive hinting
  const wantsYes = lower.includes("should i") || lower.includes("do i") || lower.includes("go for");
  const roll = Math.random();

  let tone = "uncertain";
  let probability = 0.5;
  let certainty = 0.32;
  let response = pick([
    "The signal is faint. Wait for clearer skies.",
    "Too much noise in the field. Gather one more data point.",
    "The pattern hasn't fully formed. Trust your instincts.",
  ]);

  if (roll > 0.70) {
    tone = wantsYes ? "cosmic-yes" : "nebula-yes";
    probability = clamp(0.72 + (Math.random() - 0.5) * 0.18, 0, 1);
    certainty = clamp(0.68 + (Math.random() - 0.5) * 0.22, 0, 1);
    response = pick([
      "Yes. The trajectory aligns — move with intent.",
      "Green light. The odds are bright in this lane.",
      "Proceed. The signal is strong and stabilizing.",
    ]);
  } else if (roll < 0.30) {
    tone = wantsYes ? "cosmic-no" : "nebula-no";
    probability = clamp(0.22 + (Math.random() - 0.5) * 0.18, 0, 1);
    certainty = clamp(0.68 + (Math.random() - 0.5) * 0.22, 0, 1);
    response = pick([
      "No. This path collapses under pressure — wait.",
      "Abort. The risk field is heavy right now.",
      "Hard no. The pattern fractures here.",
    ]);
  } else {
    tone = wantsYes ? "nebula-yes" : "nebula-no";
    probability = clamp(0.55 + (Math.random() - 0.5) * 0.2, 0, 1);
    certainty = clamp(0.55 + (Math.random() - 0.5) * 0.25, 0, 1);
    response = pick([
      "Leaning yes… but keep a fallback close.",
      "Leaning no… unless you can reduce the downside.",
      "Cautiously favorable — stay alert and adaptable.",
    ]);
  }

  return {
    response,
    tone,
    probability,
    certainty,
    reasoning: "Mock response (set VITE_LLM_ENDPOINT to use a real model).",
  };
}

async function invokeViaEndpoint({ prompt, response_json_schema }) {
  const endpoint = import.meta.env.VITE_LLM_ENDPOINT;
  if (!endpoint) return mockFromPrompt(prompt);

  const token = import.meta.env.VITE_LLM_BEARER_TOKEN;

  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({
      prompt,
      schema: response_json_schema ?? null,
    }),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`LLM endpoint error: ${res.status} ${res.statusText} ${text}`);
  }

  return res.json();
}

export const base44 = {
  integrations: {
    Core: {
      InvokeLLM: invokeViaEndpoint,
    },
  },
};
