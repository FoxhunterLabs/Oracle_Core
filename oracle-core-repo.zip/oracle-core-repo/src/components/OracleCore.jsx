import React, { useEffect, useMemo, useRef, useState } from "react";
import { Sparkles, Zap, Eye, RefreshCw } from "lucide-react";
import { base44 } from "@/api/base44Client";

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

function lerp(a, b, t) {
  return a + (b - a) * t;
}

// Seed-ish RNG so effects feel consistent per session
function mulberry32(seed) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const OracleCore = () => {
  const canvasRef = useRef(null);
  const wrapRef = useRef(null);
  const burstRef = useRef(0);

  const [question, setQuestion] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [prediction, setPrediction] = useState(null);
  const [error, setError] = useState(null);

  const detectCategory = (text) => {
    const lower = text.toLowerCase();
    if (lower.match(/job|career|work|hire|promotion|boss|salary/)) return "career";
    if (lower.match(/money|buy|invest|spend|save|cost|price|dollar/)) return "financial";
    if (lower.match(/love|date|relationship|marry|partner|friend|family/)) return "relationship";
    if (lower.match(/health|exercise|diet|doctor|sleep|fitness/)) return "health";
    return "personal";
  };

  const generatePrediction = async (questionText) => {
    const category = detectCategory(questionText);

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: `You are the Oracle Core, a mystical AI prediction engine that analyzes questions and provides cosmic, concise guidance.

Question: "${questionText}"
Category: ${category}

Analyze this question deeply and provide a prediction. Your response should be:
- Concise and powerful (1-2 sentences max)
- Mystical/cosmic in tone
- Either strongly affirmative, strongly negative, cautiously optimistic, cautiously pessimistic, or uncertain
- Use metaphors like "trajectory," "signal," "pattern," "stars," "odds," "path," etc.

Provide your response in this exact JSON format:
{
  "response": "Your mystical response here",
  "tone": "cosmic-yes" | "cosmic-no" | "nebula-yes" | "nebula-no" | "uncertain",
  "probability": 0.0-1.0 (your confidence this will happen/is a good idea),
  "certainty": 0.0-1.0 (how confident you are in your prediction),
  "reasoning": "Brief explanation of your analysis"
}

Tone guide:
- cosmic-yes: Strong yes (prob 0.7-0.95, certainty 0.7+)
- cosmic-no: Strong no (prob 0.05-0.3, certainty 0.7+)
- nebula-yes: Cautious yes (prob 0.55-0.75, certainty 0.4-0.7)
- nebula-no: Cautious no (prob 0.25-0.45, certainty 0.4-0.7)
- uncertain: Not enough signal (prob ~0.5, certainty <0.4)`,
      response_json_schema: {
        type: "object",
        properties: {
          response: { type: "string" },
          tone: {
            type: "string",
            enum: ["cosmic-yes", "cosmic-no", "nebula-yes", "nebula-no", "uncertain"],
          },
          probability: { type: "number" },
          certainty: { type: "number" },
          reasoning: { type: "string" },
        },
        required: ["response", "tone", "probability", "certainty"],
      },
    });

    return {
      question: questionText,
      response: response.response,
      tone: response.tone,
      category,
      probability: clamp(response.probability, 0, 1),
      certainty: clamp(response.certainty, 0, 1),
      reasoning: response.reasoning,
      timestamp: new Date().toISOString(),
    };
  };

  // ====== Particle engine ======
  const seed = useMemo(() => Math.floor(Math.random() * 1e9), []);
  const rand = useMemo(() => mulberry32(seed), [seed]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;

    const ctx = canvas.getContext("2d");
    let w = 0,
      h = 0,
      dpr = 1;

    const pointer = { x: 0, y: 0, vx: 0, vy: 0, down: false };
    const camera = { shake: 0, drift: 0 };

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = Math.floor(rect.width);
      h = Math.floor(rect.height);
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    window.addEventListener("resize", resize);

    const onMove = (e) => {
      const rect = wrap.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      pointer.vx = x - pointer.x;
      pointer.vy = y - pointer.y;
      pointer.x = x;
      pointer.y = y;
    };

    const onDown = () => {
      pointer.down = true;
    };
    const onUp = () => {
      pointer.down = false;
    };

    wrap.addEventListener("mousemove", onMove);
    wrap.addEventListener("mousedown", onDown);
    window.addEventListener("mouseup", onUp);

    // Star layers for parallax depth
    const layers = [
      { count: 120, speed: 0.15, size: [0.7, 1.5], alpha: [0.25, 0.55] },
      { count: 80, speed: 0.35, size: [1.2, 2.2], alpha: [0.35, 0.7] },
      { count: 40, speed: 0.65, size: [1.8, 3.2], alpha: [0.5, 0.9] },
    ];

    const stars = layers.map((L) =>
      Array.from({ length: L.count }).map(() => ({
        x: rand() * w,
        y: rand() * h,
        z: rand(),
        r: lerp(L.size[0], L.size[1], rand()),
        a: lerp(L.alpha[0], L.alpha[1], rand()),
        tw: rand() * Math.PI * 2,
      }))
    );

    // Energy particles (vortex & burst)
    const energy = Array.from({ length: 220 }).map(() => ({
      x: w * 0.5 + (rand() - 0.5) * w,
      y: h * 0.55 + (rand() - 0.5) * h,
      vx: (rand() - 0.5) * 0.4,
      vy: (rand() - 0.5) * 0.4,
      life: rand(),
      size: lerp(0.6, 2.8, rand()),
      hue: lerp(190, 295, rand()),
    }));

    let last = performance.now();
    let vortex = 0;
    let burst = 0;

    const tick = (now) => {
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;

      ctx.clearRect(0, 0, w, h);

      // soft nebula gradients
      const g1 = ctx.createRadialGradient(
        w * 0.2,
        h * 0.3,
        0,
        w * 0.2,
        h * 0.3,
        Math.max(w, h) * 0.8
      );
      g1.addColorStop(0, "rgba(120, 60, 255, 0.22)");
      g1.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = g1;
      ctx.fillRect(0, 0, w, h);

      const g2 = ctx.createRadialGradient(
        w * 0.8,
        h * 0.7,
        0,
        w * 0.8,
        h * 0.7,
        Math.max(w, h) * 0.9
      );
      g2.addColorStop(0, "rgba(0, 220, 255, 0.14)");
      g2.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = g2;
      ctx.fillRect(0, 0, w, h);

      ctx.fillStyle = "rgba(0,0,0,0.15)";
      ctx.fillRect(0, 0, w, h);

      const vign = ctx.createRadialGradient(
        w * 0.5,
        h * 0.55,
        Math.min(w, h) * 0.2,
        w * 0.5,
        h * 0.55,
        Math.max(w, h) * 0.7
      );
      vign.addColorStop(0, "rgba(0,0,0,0)");
      vign.addColorStop(1, "rgba(0,0,0,0.55)");
      ctx.fillStyle = vign;
      ctx.fillRect(0, 0, w, h);

      camera.drift += dt * 0.2;
      const driftX = Math.sin(camera.drift) * 4;
      const driftY = Math.cos(camera.drift * 0.8) * 3;

      // burst ring lerp
      burst = lerp(burst, burstRef.current, 0.2);
      burstRef.current = lerp(burstRef.current, 0, 0.06);

      camera.shake = lerp(camera.shake, burst > 0.02 ? 8 : 0, 0.08);
      const shakeX = (rand() - 0.5) * camera.shake;
      const shakeY = (rand() - 0.5) * camera.shake;

      ctx.save();
      ctx.translate(driftX + shakeX, driftY + shakeY);

      // parallax stars
      for (let li = 0; li < stars.length; li++) {
        const L = layers[li];
        const arr = stars[li];

        for (const s of arr) {
          s.tw += dt * (0.6 + s.z * 1.2);
          const tw = 0.75 + Math.sin(s.tw) * 0.25;

          const dx = (pointer.x - w * 0.5) * (L.speed * 0.08);
          const dy = (pointer.y - h * 0.55) * (L.speed * 0.08);

          ctx.beginPath();
          ctx.fillStyle = `rgba(255,255,255,${s.a * tw})`;
          ctx.arc(s.x - dx, s.y - dy, s.r, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // oracle core glow
      const cx = w * 0.5;
      const cy = h * 0.45;

      const coreR = Math.min(w, h) * 0.14;
      const glow = ctx.createRadialGradient(
        cx - coreR * 0.25,
        cy - coreR * 0.35,
        coreR * 0.15,
        cx,
        cy,
        coreR * 1.6
      );
      glow.addColorStop(0, `rgba(255,255,255,${0.22 + vortex * 0.2})`);
      glow.addColorStop(0.3, `rgba(170,90,255,${0.16 + vortex * 0.22})`);
      glow.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = glow;
      ctx.fillRect(cx - coreR * 2, cy - coreR * 2, coreR * 4, coreR * 4);

      const sphere = ctx.createRadialGradient(
        cx - coreR * 0.35,
        cy - coreR * 0.45,
        coreR * 0.2,
        cx,
        cy,
        coreR
      );
      sphere.addColorStop(0, `rgba(255,255,255,${0.28 + vortex * 0.18})`);
      sphere.addColorStop(0.35, "rgba(120,70,255,0.20)");
      sphere.addColorStop(0.7, "rgba(20,12,50,0.95)");
      sphere.addColorStop(1, "rgba(0,0,0,1)");
      ctx.beginPath();
      ctx.fillStyle = sphere;
      ctx.arc(cx, cy, coreR, 0, Math.PI * 2);
      ctx.fill();

      const targetVortex = isAnalyzing ? 1 : 0;
      vortex = lerp(vortex, targetVortex, 0.06);

      const pull = 0.6 + vortex * 2.1;
      const swirl = 1.4 + vortex * 3.5;

      for (const p of energy) {
        const dx = cx - p.x;
        const dy = cy - p.y;
        const dist = Math.max(40, Math.hypot(dx, dy));

        const sx = -dy / dist;
        const sy = dx / dist;

        p.vx += (dx / dist) * pull * dt;
        p.vy += (dy / dist) * pull * dt;

        p.vx += sx * swirl * dt;
        p.vy += sy * swirl * dt;

        const mdx = pointer.x - p.x;
        const mdy = pointer.y - p.y;
        const md = Math.max(60, Math.hypot(mdx, mdy));
        const mousePull = pointer.down ? 2.4 : 1.0;
        p.vx += (mdx / md) * 0.25 * dt * mousePull;
        p.vy += (mdy / md) * 0.25 * dt * mousePull;

        p.x += p.vx * 60 * dt;
        p.y += p.vy * 60 * dt;

        p.vx *= 0.985;
        p.vy *= 0.985;

        if (p.x < -100 || p.x > w + 100 || p.y < -100 || p.y > h + 100) {
          p.x = cx + (rand() - 0.5) * w * 0.9;
          p.y = cy + (rand() - 0.5) * h * 0.9;
          p.vx = (rand() - 0.5) * 0.25;
          p.vy = (rand() - 0.5) * 0.25;
        }

        const alpha = clamp(0.15 + vortex * 0.55, 0.05, 0.85);
        ctx.beginPath();
        ctx.fillStyle = `hsla(${p.hue}, 95%, 70%, ${alpha})`;
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }

      // reveal ring
      if (burst > 0.01) {
        const ring = coreR * (1 + burst * 6);
        ctx.beginPath();
        ctx.strokeStyle = `rgba(255,255,255,${0.55 * burst})`;
        ctx.lineWidth = 2;
        ctx.arc(cx, cy, ring, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.restore();

      requestAnimationFrame(tick);
    };

    const raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      wrap.removeEventListener("mousemove", onMove);
      wrap.removeEventListener("mousedown", onDown);
      window.removeEventListener("mouseup", onUp);
    };
  }, [rand, isAnalyzing]);

  const ask = async () => {
    if (!question.trim() || isAnalyzing) return;

    setError(null);
    setIsAnalyzing(true);
    setPrediction(null);

    try {
      const p = await generatePrediction(question.trim());

      // cinematic delay
      await new Promise((r) => setTimeout(r, 650));

      setPrediction(p);
      burstRef.current = 1; // trigger ring burst
    } catch (e) {
      console.error(e);
      setError(e?.message || "Prediction failed.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const toneBadge = (tone) => {
    switch (tone) {
      case "cosmic-yes":
        return "bg-emerald-500/20 border-emerald-400 text-emerald-200";
      case "cosmic-no":
        return "bg-rose-500/20 border-rose-400 text-rose-200";
      case "nebula-yes":
        return "bg-cyan-500/20 border-cyan-400 text-cyan-200";
      case "nebula-no":
        return "bg-amber-500/20 border-amber-300 text-amber-100";
      default:
        return "bg-white/10 border-white/20 text-white/80";
    }
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      <div ref={wrapRef} className="relative h-screen w-full">
        {/* Particle Canvas */}
        <canvas ref={canvasRef} className="absolute inset-0" />

        {/* Floating UI */}
        <div className="absolute inset-0 flex items-center justify-center px-6">
          <div className="w-full max-w-3xl">
            <div className="mb-6 text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/15 bg-white/5 backdrop-blur-md shadow-[0_0_40px_rgba(120,60,255,0.15)]">
                <Eye className="w-4 h-4 opacity-80" />
                <span className="text-sm tracking-wide opacity-80">
                  AI-Powered Prediction Engine
                </span>
              </div>

              <h1 className="mt-4 text-5xl font-bold tracking-tight">
                <span className="bg-gradient-to-r from-white via-violet-200 to-cyan-200 bg-clip-text text-transparent">
                  Oracle Core
                </span>
              </h1>
              <p className="mt-2 text-white/70">
                Ask a question. Watch the AI render a probability.
              </p>
            </div>

            {/* Core Panel */}
            <div className="rounded-3xl border border-white/15 bg-white/5 backdrop-blur-xl p-6 shadow-[0_0_60px_rgba(0,220,255,0.08)]">
              <div className="flex gap-3">
                <input
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && ask()}
                  placeholder="Should I invest in this new venture?"
                  className="flex-1 rounded-2xl bg-black/40 border border-white/15 px-5 py-4 text-lg outline-none focus:ring-4 focus:ring-violet-500/30 placeholder:text-white/35"
                />

                <button
                  onClick={ask}
                  disabled={!question.trim() || isAnalyzing}
                  className="rounded-2xl px-6 py-4 font-semibold bg-gradient-to-r from-violet-600 to-cyan-500 hover:from-violet-500 hover:to-cyan-400 transition disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_0_30px_rgba(120,60,255,0.25)] flex items-center gap-2"
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      Analyzing…
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      Predict
                    </>
                  )}
                </button>
              </div>

              {/* Error */}
              {error && (
                <div className="mt-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
                  {error}
                </div>
              )}

              {/* Result */}
              <div className="mt-6 min-h-[110px]">
                {!prediction && !isAnalyzing && !error && (
                  <div className="text-center text-white/60">
                    <p className="text-lg">The core is idle.</p>
                    <p className="text-sm mt-1">
                      Move your mouse. Hold click to bend the field.
                    </p>
                  </div>
                )}

                {isAnalyzing && (
                  <div className="text-center">
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/15 bg-white/5">
                      <Zap className="w-4 h-4 text-cyan-200" />
                      <span className="text-sm text-white/80">
                        Consulting the cosmic intelligence…
                      </span>
                    </div>
                    <p className="mt-4 text-2xl font-semibold text-white">
                      The AI is calculating your future.
                    </p>
                  </div>
                )}

                {prediction && !isAnalyzing && (
                  <div className="text-center">
                    <div
                      className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border ${toneBadge(
                        prediction.tone
                      )}`}
                    >
                      <span className="text-sm font-medium tracking-wide">
                        {prediction.category.toUpperCase()}
                      </span>
                      <span className="text-white/40">•</span>
                      <span className="text-sm">
                        {(prediction.certainty * 100).toFixed(0)}% certainty
                      </span>
                    </div>

                    <p className="mt-4 text-3xl font-semibold leading-tight">
                      {prediction.response}
                    </p>

                    <p className="mt-3 text-white/60 text-sm">
                      Probability signal:{" "}
                      <span className="text-white/80 font-medium">
                        {(prediction.probability * 100).toFixed(0)}%
                      </span>
                    </p>

                    {prediction.reasoning && (
                      <p className="mt-3 text-white/50 text-xs max-w-md mx-auto">
                        {prediction.reasoning}
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Subtle footer */}
            <div className="mt-6 flex justify-center">
              <div className="text-xs text-white/40 border border-white/10 bg-white/5 px-3 py-2 rounded-full backdrop-blur-md">
                Tip: click + drag to distort particles like gravity.
              </div>
            </div>
          </div>
        </div>

        {/* Corner glows */}
        <div className="pointer-events-none absolute -top-24 -left-24 w-[500px] h-[500px] bg-violet-600/20 blur-3xl rounded-full" />
        <div className="pointer-events-none absolute -bottom-24 -right-24 w-[600px] h-[600px] bg-cyan-500/15 blur-3xl rounded-full" />
      </div>
    </div>
  );
};

export default OracleCore;
