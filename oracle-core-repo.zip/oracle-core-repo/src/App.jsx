import OracleCore from './components/OracleCore.jsx'

export default function App() {
  return <OracleCore />
}
