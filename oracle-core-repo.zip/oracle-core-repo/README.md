# Oracle Core

A deep-space, particle-driven prediction UI built with React + Vite + Tailwind.

## Run locally

```bash
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173).

## LLM hookup (optional)

This repo includes a tiny **client-side** `base44Client` stub at `src/api/base44Client.js`.

- If you set `VITE_LLM_ENDPOINT` in a `.env` file, the app will `POST` `{ prompt, schema }` to that endpoint and expect JSON back.
- If you don't set it, the app falls back to a local mock (still returns the right JSON shape).

Create `.env` (or copy from `.env.example`):

```bash
cp .env.example .env
```

Then edit `.env`:

```env
VITE_LLM_ENDPOINT=https://your-api.example.com/invoke-llm
VITE_LLM_BEARER_TOKEN=
```

### Expected response JSON

Your endpoint should return:

```json
{
  "response": "string",
  "tone": "cosmic-yes | cosmic-no | nebula-yes | nebula-no | uncertain",
  "probability": 0.0,
  "certainty": 0.0,
  "reasoning": "string (optional)"
}
```

> ⚠️ Security note: do **not** put real API keys in Vite `VITE_*` env vars for a public deployment. Those are shipped to the browser. For production, proxy through a serverless function / backend.

## Push to your GitHub repo

If you already created an empty GitHub repo:

```bash
git init
git add .
git commit -m "Initial Oracle Core app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

If your GitHub repo already has a README/commit, do this instead:

```bash
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git pull origin main --rebase
git push -u origin main
```

## Project structure

- `src/components/OracleCore.jsx` — the UI + canvas particle engine
- `src/api/base44Client.js` — stub client that calls your LLM endpoint or a mock
